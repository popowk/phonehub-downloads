param([Parameter(Mandatory=$true)][string]$LinkPath,[Parameter(Mandatory=$true)][string]$SourcePath)
$ErrorActionPreference='Stop'
New-Item -ItemType Junction -Path $LinkPath -Target $SourcePath | Out-Null
